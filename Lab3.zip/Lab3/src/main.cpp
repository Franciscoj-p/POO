#include "../include/sistemaConsultorio.h"

int main() {
    SistemaConsultorio sistema;
    sistema.mostrarMenu();  
    return 0;
}
